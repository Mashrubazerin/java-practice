public class Method {

    public void sum (int a,int b)
    {
        int sum=a+b;
        System.out.print(sum);
    }
    public static void main(String args[]) {
        Method ob=new Method ();
        ob.sum(10,20);
        
        
    }
    
}
