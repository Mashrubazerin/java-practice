
    int c;
public Mid(int a,int b, int c)