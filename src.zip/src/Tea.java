public class Tea{
   String des="Lecturer";
   String uni="daf";
   float salary=112.88f;

}