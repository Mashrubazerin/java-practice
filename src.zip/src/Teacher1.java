public class Teacher1 {
    String name;
    int age;
    public void behave()
    {
        System.out.println("Teaching");
    }
}
