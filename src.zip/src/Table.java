public class Table {
    int height;
    int width;
    public static void main(String args[]) {
        Table t1=new Table();
        t1.height=12;
        t1.width=14;
        System.out.println("height and width is "+t1.height+t1.width);
    }
    
}
