public class Teacher {
    String designation="lecturer";
    String Uniname="diu";
public void job(){
    System.out.println("Teaching");
}
}
