public class Employeee {
    float salary;
    public float total (float a,float b){
        float x= a+b;
        return x;
    }
}

