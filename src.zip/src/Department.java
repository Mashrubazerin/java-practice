public class Department {
    String deptName;
    int deptCode;
    String faculty;
}
