public class Employeee1 {
    double salary;
    double bonus;
    public void meth(double a,double b){
        salary=a;
        bonus=b;
        double total=salary+bonus;
        System.out.println("Total is "+total);
    }
}
