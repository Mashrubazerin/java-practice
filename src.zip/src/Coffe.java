public class Coffe extends Tea{
    String sub="Software";
    public static void main(String args[]){
        Coffe cup=new Coffe();

        int age=12;
        System.out.println(cup.des+ cup.uni+ cup.salary+age);
    }
    
}
