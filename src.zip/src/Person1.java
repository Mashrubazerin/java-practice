public class Person1 {
    protected String name;
    protected int age;
    
}
