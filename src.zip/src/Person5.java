public class Person5 {
    protected String name;
    protected int age;
}
