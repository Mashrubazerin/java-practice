public class Box{
    int height;
    int width;
    public static void main(String args[])
    {
        Box b= new Box();
        b.height= 5;
        b.width= 4;
        System.out.println("height is "+b.height+"\nWidht izz "+b.width);

    }
}