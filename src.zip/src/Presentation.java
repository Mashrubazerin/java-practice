public class Presentation {
    String name;
    int id;
    String topic;
    public static void main (String args [])
    {
        Presentation std1= new Presentation();
        Presentation std2= new Presentation();
        std1.name="Nazafi";
        std1.id=885;
        std1.topic="shah rukh khan";
        std2.name="dipu";
        std2.id=873;
        std2.topic="salman khan";
        System.out.println("Student 1 information "+std1.name+" "+std1.topic+" "+std1.id);
        System.out.print("Student 2 information "+std2.name+" "+std2.topic+" "+std2.id);

    


    }
}
